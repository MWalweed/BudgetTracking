/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.budgettracker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

class Transaction {
    String type;
    double amount;
    String description;

    public Transaction(String type, double amount, String description) {
        this.type = type;
        this.amount = amount;
        this.description = description;
    }

    @Override
    public String toString() {
        return type + ": $" + amount + " - " + description;
    }
}

class User {
    String username;
    String password;
    ArrayList<Transaction> transactions;
    double balance;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.transactions = new ArrayList<>();
        this.balance = 0;
    }
    
    public void addIncome(double amount, String description) {
        transactions.add(new Transaction("Income", amount, description));
        balance += amount;
    }

    public void addExpense(double amount, String description) {
        transactions.add(new Transaction("Expense", amount, description));
        balance -= amount;
    }
    
    public void showTransactions() {
        if (transactions.isEmpty()) {
            System.out.println("No transactions recorded.");
            return;
        }
        for (Transaction t : transactions) {
            System.out.println(t);
        }
    }
    
    public void showBalance() {
        System.out.println("Current balance: $" + balance);
    }
}

public class BudgetTracker {
    private static HashMap<String, User> users = new HashMap<>();
    private static Scanner scanner = new Scanner(System.in);
    private static User loggedInUser;

    public static void signUp() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        
        if (users.containsKey(username)) {
            System.out.println("Username already exists. Try logging in.");
            return;
        }
        
        User newUser = new User(username, password);
        users.put(username, newUser);
        System.out.println("User registered successfully. Please log in.");
    }

    public static boolean signIn() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        
        if (users.containsKey(username) && users.get(username).password.equals(password)) {
            loggedInUser = users.get(username);
            System.out.println("Logged in successfully.");
            return true;
        } else {
            System.out.println("Invalid credentials. Try again.");
            return false;
        }
    }

    public static void main(String[] args) {
        while (true) {
            System.out.println("1. Sign Up");
            System.out.println("2. Sign In");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");
            int choice = Integer.parseInt(scanner.nextLine());
            
            switch (choice) {
                case 1:
                    signUp();
                    break;
                case 2:
                    if (signIn()) {
                        userMenu();
                    }
                    break;
                case 3:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
    
    private static void userMenu() {
        while (true) {
            System.out.println("1. Add Income");
            System.out.println("2. Add Expense");
            System.out.println("3. Show Transactions");
            System.out.println("4. Show Balance");
            System.out.println("5. Log Out");
            System.out.print("Enter choice: ");
            int choice = Integer.parseInt(scanner.nextLine());
            
            switch (choice) {
                case 1:
                    System.out.print("Enter amount: ");
                    double incomeAmount = Double.parseDouble(scanner.nextLine());
                    System.out.print("Enter description: ");
                    String incomeDescription = scanner.nextLine();
                    loggedInUser.addIncome(incomeAmount, incomeDescription);
                    break;
                case 2:
                    System.out.print("Enter amount: ");
                    double expenseAmount = Double.parseDouble(scanner.nextLine());
                    System.out.print("Enter description: ");
                    String expenseDescription = scanner.nextLine();
                    loggedInUser.addExpense(expenseAmount, expenseDescription);
                    break;
                case 3:
                    loggedInUser.showTransactions();
                    break;
                case 4:
                    loggedInUser.showBalance();
                    break;
                case 5:
                    System.out.println("Logging out...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}



